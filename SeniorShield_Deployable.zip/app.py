
import streamlit as st
from PIL import Image
import pytesseract

st.set_page_config(page_title="SeniorShield", layout="centered")

st.markdown("""
    <style>
        [data-testid="stSidebar"] {display: none;}
    </style>
""", unsafe_allow_html=True)

st.markdown("<h1 style='font-size: 50px;'>🛡️ SeniorShield</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='font-size: 26px;'>Upload a screenshot to check for scam signs</h3>", unsafe_allow_html=True)
st.markdown("---")

uploaded_file = st.file_uploader("📷 Upload screenshot (PNG, JPG, JPEG)", type=["png", "jpg", "jpeg"])

if uploaded_file:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    st.markdown("### 🔍 Extracted Text:")
    extracted_text = pytesseract.image_to_string(image)
    st.code(extracted_text)

    scam_keywords = [
        "bank account", "otp", "login here", "click link", "urgent",
        "singpass", "verify", "reward", "lucky draw", "password", "transfer"
    ]

    scam_count = sum(1 for kw in scam_keywords if kw.lower() in extracted_text.lower())

    st.markdown("### 🔎 Scam Risk Analysis")
    if scam_count >= 2:
        st.error("🚨 Warning: This message has multiple scam-related terms.")
    elif scam_count == 1:
        st.warning("⚠️ Caution: This message has 1 suspicious keyword. Stay alert.")
    else:
        st.success("✅ No obvious scam terms found. But always verify suspicious messages.")
